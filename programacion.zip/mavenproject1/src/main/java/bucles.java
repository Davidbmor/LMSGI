
import java.math.BigInteger;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author David
 */
public class bucles {

    @SuppressWarnings("empty-statement")
    public static void main(String args[]) {
//        loopwhile();
//        loopfor();
//        loopdowhile();
//        ejercicio1();
//        ejercicio2();
//        ejercicio3();
//        ejercicio4();
//        ejercicio5();
//     
//        ejercicio6();
//        ejercicio7();
//        ejerciciou();
//          ejercicio8();
//        simulacro();
            digitosNumericos();
    }

    public static void loopwhile() {
        byte i;
        System.out.println("Writing form 1 to 10 with while");
        i = 1;
        while (i <= 10) {
            System.out.println(i + " ");
            i++;
        }
        System.out.println(" \n The end");
    }

    public static void loopfor() {
//        for (int i = 0 ; i<=10 ; i++) {
//      
//            System.out.print(i); // 0 1 2 3 4 5 6 7 8 9 
//        }
//        for (int i = 10 ; i>=1 ; i--) {
//      
//            System.out.print(i + " "); // 0 1 2 3 4 5 6 7 8 9 
//        }
//        for (int i = 15; i >= 2; i= i-2) {
//            
//            
//
//            System.out.print(i++ + " "); // 0 1 2 3 4 5 6 7 8 9 
//            i = i-3;
//        }
//        final int MAX = 6;
//        for (int i = MAX; i>= 1 ; i--) { //Filas 
//            System.out.println(" ");
//            for (int j = 1; j <= i; j++) { //Columnas 
//                System.out.print(j + " ");
//
//            }
//
//        }
// al revés 

        for (int i = 1; i <= 6; i++) { //Filas 
            System.out.println(" ");
            for (int j = 1; j <= i; j++) { //Columnas 
                System.out.print(j + " ");

            }

        }
    }

    public static void loopdowhile() {
        byte i = 10;
        System.out.println("Writing form 1 to 10 with while");
        do {
            System.out.println(i + " ");
            i--;

        } while (i >= 1);

    }

    public static void ejercicio1() {

        byte i = 10;
        System.out.println("Writing form 1 to 10 with while");
        do {
            System.out.println(i + " ");
            i--;

        } while (i >= 1);
        {
        }

    }

    public static void ejercicio2() {

        int i = 2;
        System.out.println("Writing form 1 to 10 with while");
        do {
            System.out.println(i + " ");
            i = i + 2;

        } while (i <= 20);
        {
        }

    }

    public static void ejercicio3() {
        int i = 19;
        System.out.println("Writing form 1 to 10 with while");
        do {
            System.out.println(i + " ");
            i = i - 2;

        } while (i >= 2);
        {
        }

    }

    public static void ejercicio4() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Intorduzca un numero ");
        int i = keyboard.nextInt();
        while (i != 3) {
            System.out.println("Intorduzca otro numero ");
            i = keyboard.nextInt();
        }

    }

    public static void ejercicio5() {
//        perdirNumeros();
//        
//        do{
//            mostrarMenu();
//            pedirOpcion();
//            if (opcion !=0){
//                realizarcalculo();
//            }
//            realizarcalculo();
//            
//        }while (opcion !=0);
//        
//        
//    }
//    
//   
//    
//    public static int pedirNumero(){
//        Scaner entrada = new Scaner (System.in);
//        
//    }
    }

    public static void ejercicio6() {

        int clave = 890;
        int user;
        Scanner keyboard = new Scanner(System.in);
        do {
            System.out.println(" Escriba una contraseña");
            user = keyboard.nextInt();

            if (user != clave) {
                System.out.println("Has fallado, vuelve a intentarlo");
            }
        } while (user != clave);

        System.out.println("Correcto , caja desbloqueada");

    }// Caja fuerte 

    public static void ejercicio7() {

        int min = 100;
        int max = 800;
        int rndl = ThreadLocalRandom.current().nextInt(min, max);
        int intentos;
        int user;
        System.out.println(rndl);
        for (intentos = 0; intentos <= 8; intentos++) {
            Scanner keyboard = new Scanner(System.in);
            do {
                intentos++;
                System.out.println(" Escriba una contraseña");
                user = keyboard.nextInt();

                if (user != rndl) {
                    System.out.println("Has fallado, vuelve a intentarlo");

                }
            } while (intentos != 8 && user != rndl);
            if (intentos == 8) {
                System.out.println("Tus intentos se han acabado");

            } else {
                System.out.println("Has abierto la caja ");
                intentos = 8;
            }

        }
    }// Variante de caja fuerte con ramdom e intentos

    public static void ejerciciou() {
        Scanner sc = new Scanner(System.in);
        double suma = 0;
        int sueldosMayores1500 = 0;

        for (int i = 1; i <= 10; i++) {
            System.out.print("Introduce el sueldo " + i + ": ");
            double sueldo = sc.nextDouble();
            suma += sueldo;

            if (sueldo > 1500) {
                sueldosMayores1500++;
            }
        }

        System.out.println("La suma de los sueldos es: " + suma + "€");
        System.out.println("Hay " + sueldosMayores1500 + " sueldos mayores de 1500€.");

    }//Salario

    public static void ejercicio8() {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("introduza un numero ");
        int num = 1;
        while (num != 0) {
            num = keyboard.nextInt();
            System.out.println("el numero introducio es " + num);
            if (num == 0) {
                System.out.println("El programa termimina ");

            } else {
                System.out.println("introduzca otro numero: ");
            }

        }
    }// Numero hasta poner un 0

    public static void simulacro() {

        Scanner sc = new Scanner(System.in);
        double num;
        double digitos;

        do {
            System.out.println("Introduzcca un numero ");
            num = sc.nextDouble();
            digitos = 0;
            while (num != 0) {
                num = num / 10;
                digitos++;
            }

            System.out.println(" El numero  tiene lo siguientes digitos " + digitos);
        } while (num == 0);

    }

    public static void digitosNumericos(){
        Scanner entrada = new Scanner (System.in);
        System.out.println("Introduzca un numero largo");
        BigInteger num = entrada.nextBigInteger();
                int digitos = 0;
                while (!num.equals (0)){
                   digitos++;
                   num = num.divide(BigInteger.valueOf(10));
                    System.out.println(num);
                           
                }
                 System.out.println("Tiene" + digitos + "digitos");   
    }
}

//        int i,j,k,n;
//        n=4;
//        for(i=1; i<n+(n/2); i++){
//            for(j=n+(n/2); j>i; j--){
//                System.out.print(" ");}
//            for(k=1; k<=2*i-1; k++){
//                System.out.print("*");}
//            System.out.println("");
//        }
//        for(i=1; i<n-(n/2); i++){
//            for(j=n+(n/2); j>1; j--){
//                System.out.print(" ");}
//            for(k=n/2; k<=(n/2)+1; k++){
//                System.out.print("*");}
//            System.out.println("");
//        }
//    }
// Controlar al condicion, cambiarla dentro de las instrucciones, cuidado con el orden de las instrucciones        System.out.println("Has fallado, buelve a intentarlo");
//mostrar por pantalla 10 al 1 
// Mostrar por pantalla del 2 al 20 pero solo los numero pares
// Mostrar por pantalla del 20 al 2 pero solo los numero impares
// Perdir y mostrar un numero al usuario hasata que inytoduzca un 3
/*Mostrar el siguiente menu
1 sumar
2 restar
3 multiplicar 
4 dividir 
5 Pedir dos numeros al usuario y segun la opcion elegifa 
 */
// Sacar  por pantalla la siguiente salida 1 , 2 ,3 ,4 ,5,6, - 
// 1 2 3 4 5 
// 1 2 3 4 5 
// 1 2 3  
// 1 2 
// 1 
// Tenemos una caja fuerte que deseamos abrir bloqueada por un candado de tres 
//numeros, pedimos al usuario que introduzca la combinacion y si es correcta 
//ponemos " Caja desbloqueada "y si no " Has fallado", sigue intentandolo 
//Variantes: Generar la combinaxion de la caja fuerte con ramdom y ademas , establecer un numero de intentos (8)
//genermamos un numero aleatorio que tenemos que advinar, cada vez que el usuario introduzca un numero le tenemos que dar una pista 
//diciendo si es mayo o menor que el numero a adivinar. Paramos cuando el usuario introduzca un cero
// Dados dos numeros escribimos los pares entre ellos inclusive
// Lo mismo pero con los impares 
// Concadenar 2 cadenas x veces`poniendo los pujntos correspondientes 
//  Pedir al usuario que introduzaca numeros enteros hasta que pulse 0 . 
//  El programa debera mostrar  : Cuantos numeros negativos he introducido ,
//  cuantos numeros positivos , la suma de los numeros introducidos y la media 
//  aritmetica de los numeros introducidos 
/*
sout   introduza un numero 
int num = 1;
while (num!=0){
num = keyboard.nextInt();
sout    el numero  introducio es +num 
 */
/*
1º hacer un casting 
        (int) 3.2 (intentom un double en int)
2º Usar los parse - integerParseInt (String ---> integer )
3º Double.valueOf
4º Double.toString
*/