
import javax.swing.JOptionPane;

public class Clase_if {

    public static void main(String args[]) {
        int dinero;
        int edad;

        edad = Integer.parseInt(JOptionPane.showInputDialog("Introduzca tu edad "));
        dinero = Integer.parseInt(JOptionPane.showInputDialog("Cuanto dinero tienes "));
        if (edad >= 18) {

            if (dinero >= 15) {
                JOptionPane.showMessageDialog(null, " Voy a la discoteca ");
                dinero = dinero - 15;

                if (dinero >= 3) {

                    JOptionPane.showMessageDialog(null, " Me compro una cocaola ");
                    dinero = dinero - 3;
                    JOptionPane.showMessageDialog(null, " El dinero que te queda es " + dinero);
                }
            } else {
                JOptionPane.showInputDialog(" Me voy pa casa ");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Me voy al cine");

            String avatar = JOptionPane.showInputDialog(" ¿Está avatar en taquilla ? y/n");
            if (avatar.equals("y")) {
                  JOptionPane.showMessageDialog(null, "Veo avatar");
                 

            }

        }

    }
}
//Discoteca 15 euros, cocaloa 3 euros avatar 8 bolos 10 helado 1
