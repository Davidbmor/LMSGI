import java.util.Scanner;

public class EJ1 {

    public static void main(String[] args) {
         // Introducir numero decimal
        Scanner keyboard = new Scanner(System.in);
         System.out.println("Introduce un numero: ");
        float number1 = keyboard.nextFloat();
         System.out.println("Introduce un numero: ");
        float number2 = keyboard.nextFloat();
        
        float multi = number1 * number2;
        float suma = number1 + number2;
        float division = number1 / number2;
        float resta = number1 - number2;
        
        System.out.println("(La multiplicación es : )" + multi);
        System.out.println("(La suma es : )" + suma);
        System.out.println("(La división es : )" + division);
        System.out.println("(La resta es : )" + resta);
       
    }
}
