
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Operadores {

    public static void main(String args[]) {
//        clases();
//        postPreIncremento();
//        relatinalOperators();
        randomnumbers();

    }

    public static void clases() {

        System.out.print("\033[H\033[2J");
        System.out.flush();

        float number1, number2;
        int modulo;

        Scanner entrada = new Scanner(System.in);
        System.out.println("Type the first number: ");
        number1 = entrada.nextFloat();
        System.out.println("Type the second number:  ");
        number2 = entrada.nextFloat();
        modulo = 7 % 2;
        System.out.println("El modulo es " + modulo);
        if (number1 == number2) {
            System.out.println("Son iguales ");
        }
        String cad1, cad2;
        cad1 = " Water";
        cad2 = "water";
        if (cad1.equals(cad1)) {
            System.out.println("Strings are equal");
        } else {
            System.out.println("Diferent strings");

        }
        double result;
        System.out.println("number1 before adition  : " + number1);
        number1 += number2; //number1  = number1 + number2
        System.out.println("number1 after adition : " + number1);

    }

    public static void postPreIncremento() {
        int a = 0;
        int b = 2;
        a++;
        System.out.println("a contains " + a);
        ++b;
        System.out.println("b containtss " + b);
//        a = 8;
//        b = 2;
        a = b++;
        System.out.println("a: " +a);
        System.out.println("b: " +b);
        a = 8;
        b = 2;
        
        int c = a+++b-++b-a;
        System.out.println("el" + c);
        
    }

    public static void relatinalOperators () {
        boolean a = true;
        boolean b = true;
        //perezote
    }
    
     public static void randomnumbers(){
         
//     
//         Scanner entrada = new Scanner(System.in);
//    	System.out.println("Intorduzca el máximo");
//    	int max = entrada.nextInt();
//    	//Generamos numeros aleatorios entre 0 y max  
//    	int rnl = (int) Math.random() * max;
//    	System.out.println("Random number 1 is: " + rnl);
//    	System.out.println("Introduzca el mínimo");
//    	int min = entrada.nextInt();
//    	int rndl = ThreadLocalRandom.current().nextInt(min,max);
//    	System.out.println("Random number 1 is: " + rndl);
        
            Scanner entrada = new Scanner(System.in);
	}

     

 
}
