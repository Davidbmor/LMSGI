
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author David
 */
public class Condicionales {

    public static void main(String args[]) {
//
//        String month;
//        System.out.println("Type the number between 1 and 12 : ");
//        Scanner keyboard = new Scanner(System.in);
//        int number = keyboard.nextInt();
//        switch (number) {
//            case 1:
//                month = "Enero";
//                break;
//            case 2:
//                month = "Febrero";
//                break;
//            case 3:
//                month = "Marzo";
//                break;
//            case 4:
//                month = "Abril";
//                break;
//            case 5:
//                month = "Mayo ";
//                break;
//            case 6:
//                month = "Junio";
//                break;
//            case 7:
//                month = "Julio";
//                break;
//            case 8:
//                month = "Agosto";
//                break;
//            case 9:
//                month = "Septiembre";
//                break;
//            case 10:
//                month = "Novienbre";
//                break;
//            case 11:
//                month = "Octubre";
//                break;
//            case 12:
//                month = "Diciembre";
//                break;
//            default:
//                month = "not a month ";
//                break;
//
//        }
//        System.out.println("The month of the year is : " + month);
        String week;
        System.out.println("Type the number between 1 and 12 : ");
        Scanner keyboard = new Scanner(System.in);
        int number = keyboard.nextInt();
        switch (number) {
            case 1:
                week = "Lunes";
                System.out.println("Voy al padel ");
                break;
            case 2:
                week = "Martes";
                System.out.println("Voy a natacion ");
                break;
            case 3:
                week = "Miercoles";
                System.out.println("Voy al padel ");
                break;
            case 4:
                week = "Jueves";
                System.out.println("Voy a natacion ");
                break;
            case 5:
                week = "Viernes";
                System.out.println("Vamos al cine ");
                break;
            case 6:
                week = "Sabado";
                System.out.println("Playa");
                break;
            case 7:
                week = "Domingo";
                System.out.println("Playa ");
                break;
        }
    }
    }
// Se pide al usuario un dia de la semana, decir a donde llevamos al niño
//luner miercoles padel , martes jueves natacion , los viernes cine, fin de semana`playa 
