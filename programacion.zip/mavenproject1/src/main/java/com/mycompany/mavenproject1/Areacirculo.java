 package com.mycompany.mavenproject1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author David
 */
public class Areacirculo {
public static void main (String[] args){
    double radio = 4;
    double area = Math.PI * Math.pow(radio,2) ;
    System.out.print(" El area del ciruclo es:" + area);
    
}
}