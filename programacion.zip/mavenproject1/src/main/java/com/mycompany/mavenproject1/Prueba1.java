package com.mycompany.mavenproject1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */



public class Prueba1 {

    public static void main(String[] args) {
        System.out.println("Esta es tu nota!");
        byte testResult1 = 9;
        byte testResult3 = 5;
        byte testResult2 = 3;
        float percentage1 = 0.6f;
        float percentage2 = 0.2f;
        float percentage3 = 0.2f;
        float FinalResult = testResult1*percentage1 + testResult2 * percentage2 +
              testResult3 * percentage3;
        System.out.print("Your final result is " + FinalResult);
              
    }
}
