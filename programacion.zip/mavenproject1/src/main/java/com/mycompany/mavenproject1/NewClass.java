package com.mycompany.mavenproject1;




public class NewClass {
public static void main (String[] args){
    double base = 4;
    double altura = 9;
    double area = (base * altura )/2;
    System.out.print (" El area del tirangulo es: " + area);
} 

}
