/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

import java.util.Scanner;


public class Mavenproject1 {

    public static void main(String[] args) {
    //uso de la clase Scanner
        Scanner keyboard = new Scanner(System.in);
        System.out.println ("Introduce un numero entero: ");
        int number = keyboard.nextInt();
         System.out.println (" Number intruduced:" + number );
        
 System.out.println ("Introduce un numero float: ");  
 
 
    float numberFloat = keyboard.nextFloat();
        
     System.out.println (" Number intruduced:" + numberFloat);
     
      
    
     System.out.println ("Introduce un numero double: ");  
 
 
    double numberDouble = keyboard.nextDouble();
        
     System.out.println (" Number intruduced:" + numberDouble);
     
 
     System.out.println ("Introduce una frase ");
    String letra  = keyboard.nextLine();
      /*
    Next y NexLine no funcionan juntos, hay que lipiar la cache
    Solución , meto un nextLine mas entre los dos 
    */ 
      keyboard.nextLine();
     System.out.println (" Number intruduced:" + letra);
     
     char caract = keyboard.next().charAt(0);
     System.out.print(" El caracter es :" + caract);
     
    
    }
}
