
import javax.swing.JOptionPane;


//public class SalidaDeDatos 
//{
//   public static void main (String[] args)
//
//           {
//               //Salida de datos formateada 
//               float sumando1 = 12345678.123456f;
//               float sumando2;
//               sumando2 =  817231.1231f;
//              double resultado = sumando1 * sumando2;
//              System.out.printf( "El resultado de multipilcar  %.2f por %.2f"
//              + " es  %.2f" , sumando1 , sumando2 , resultado );
//              
//               System.out.println("El resultado de multiplicar " + sumando1 +
//                 "por " + sumando2 + "es " + resultado ); 
//               
//           }
//   
//}

public class SalidaDeDatos 
{
   public static void main (String[] args){
//       int sister1 = 32;
//       float sister2 = 7;
//       String Sistername1 = "Pedro" ;
//       String Sistername2 = "Belen" ;
//       float divi = sister1 /sister2 ;
//       System.out.printf("La edad de %s entre la edad de %s es igual a "
//               + "%.2f " , Sistername1,Sistername2,divi );
//    
//       
//       // Uso de JOptionPane
//      String seisterName1 = JOptionPane.showInputDialog("Type ur sister name");
//      byte sisterAge  = Byte.parseByte(JOptionPane.showInputDialog("Type ur sister age"));
//       
//       JOptionPane.showMessageDialog(null, "ur sister name is " + seisterName1 + " and she is " + sisterAge);


       int entero = Integer.parseInt (JOptionPane.showInputDialog ("Introduzca un entero"));
       char car = JOptionPane.showInputDialog ("Introduzca un caracter").charAt(0);
       double decimal = Double.parseDouble (JOptionPane.showInputDialog ("Introduzca un decimal ")); 
       float flotante = Float.parseFloat (JOptionPane.showInputDialog ("Introduzca un flotante"));
       JOptionPane.showMessageDialog(null, " EL numero entero es "
               + entero + " El caracter es " + car + "  El decimal es "+ decimal
               + " El flotante es " + flotante);
       
       
   }
   }
 